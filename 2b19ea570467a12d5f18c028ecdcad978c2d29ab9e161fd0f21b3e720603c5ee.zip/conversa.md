--------------- Aqui Foi Feito Para Conversar ---------------

-- > Jm: 

-- > Rk: 