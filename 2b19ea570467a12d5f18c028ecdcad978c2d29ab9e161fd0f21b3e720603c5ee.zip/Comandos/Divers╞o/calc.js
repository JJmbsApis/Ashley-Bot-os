module.exports = {
  name: "calcular",
  aliases: ['calculate', 'calc'],
  code: `
・**$message[1] $message[2] $message[3] = $numberSeparator[$math[$message];,]**
  $onlyIf[$isNumber[$message[3]]==true;:x: | A terceira mensagem precisa ser um __NÚMERO__.]
  $onlyIf[$isNumber[$message[1]]==true;:x: | A primeira mensagem precisa ser um __NÚMERO__.]

  $suppressErrors[:thinking: | Talvez eu seja burra, mas tenho certeza que ** [ \`$message\` ] ** não é uma expressão válida.]
  $argsCheck[>0;**( :x: )** Coloque uma conta válida.]
$onlyIf[$argsCount==3;Coloque a Expressão __SEPARADA__ Exemplo: **1 + 1**]
$onlyIf[$checkContains[$message;\`;\`\`]==false;:x: | Por que está colocando esses caracteres?]`
} 
