module.exports = {
 name: "$alwaysExecute",
 code: `
 $setUserVar[messages;$sum[$getUserVar[messages;$authorID];1];$authorID;$guildID]
 `
}