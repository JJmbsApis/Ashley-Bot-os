module.exports = {
  name: "laranjo",
  aliases: ['orange'],
  code: `
$argsCheck[>0; :x: | <@$authorID>, Coloque Algo!]
https://arsighta.sirv.com/laranjo-meme-cke.jpg?text.0.text=$uri[$message]&text.0.position=south&text.5.size=55&text.0.color=000000
`
}