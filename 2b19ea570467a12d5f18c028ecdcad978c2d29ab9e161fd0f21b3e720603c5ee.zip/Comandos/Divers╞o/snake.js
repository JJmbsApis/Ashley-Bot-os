module.exports = {
    name: 'snake',
    aliases: ['snk'],
    code: `
  $djsEval[(async () => {
  const { Snake } = require('discord-gamecord')
  
  new Snake({
    message: message,
    slash_command: false,
    embed: {
     title: 'Jogo da Cobra :snake:',
     color: '#000000',
     overTitle: 'Fim de jogo!'
  },
    snake: { head: '🟡', body: '⬜', tail: '🟡', over: '☠️' },
    emojis: {
     board: '⬛',
     food: '🍒',
     up: '⬆️',
     right: '➡️',
     down: '⬇️',
     left: '⬅️'
  },
    foods: ['🍒', '🍅', '🍇', '🍎'],
    stopButton: 'Encerrar',
    othersMessage: '❌ | Você não pode jogar o jogo dos outros.'
  }).startGame();
  })()]
  `
  } 