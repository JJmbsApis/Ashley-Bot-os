module.exports = {
name: "ship",
aliases: ['shipar'],
$if: "v4",
code: `
$title[1;Shipado 💖]
$description[1;**Hmm, será que temos um novo casal aqui?**
\`$user[$mentioned[1]]\`
\`$user[$mentioned[2]]\`

\`$cropText[$user[$mentioned[1]];4]$replaceText[$replaceText[$user[$mentioned[2]];$cropText[$user[$mentioned[2]];4];;1]; ;;1]\` $randomText[**$random[0;5]%** Sem Chance.;**$random[6;15]%** Mehhh.;**$random[16;25]%** Até que rola.;**$random[26;45]%** \`$randomText[$user[$mentioned[1]];$user[$mentioned[2]]]\` está Só na Friendzone...;**$random[46;75]%** se \`$randomText[$user[$mentioned[1]];$user[$mentioned[2]]]\` quiser, rola!.;**$random[76;90]%** São bff.;**$random[91;100]%** Casal mais perfeito q eu.]]
$image[1;https://c.tenor.com/BnB2TTVrcAMAAAAC/haze-lena.gif]
$onlyIf[$mentionedUsersCount==2;Mencione 2 Usuários __VÁLIDOS__!]

`
}