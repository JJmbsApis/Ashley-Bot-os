module.exports = {
    name: 'prefix',
    aliases: ['setprefix', 'prefixo', 'sp', 'prefixset'],
    $if: "v4",
    code: `
$onlyIf[$message!=;Meu prefixo nesse servidor é: \`$getServerVar[Prefix]\`. para mudá-lo digite: \`$getServerVar[Prefix]prefix <novo|reset>\`]
$onlyPerms[manageserver;Você não tem permissão para isso!]
$if[$checkCondition[$message==reset]==false]
$setServerVar[Prefix;$message;$guildID]
  Prefixo setado para: \`$message\`.
$else
$setServerVar[Prefix;a*;$guildID]
  Prefixo resetado.
$endif
  `
  }