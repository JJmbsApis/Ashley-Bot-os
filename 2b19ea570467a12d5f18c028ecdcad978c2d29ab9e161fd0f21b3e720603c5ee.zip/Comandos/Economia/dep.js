module.exports = {
 name: "depositar",
 aliases: ['dep', 'deposito', 'depo'],
 code: `
**[ 💸 \]** <@$authorID> depositou \`$numberSeparator[$get[mds]]\` AyCoins no Banco! (<t:$truncate[$divide[$dateStamp;1000]]:R>).

$setGlobalUserVar[coins;$sub[$getGlobalUserVar[coins;$authorID];$get[mds]];$mentioned[1]]

$setGlobalUserVar[banco;$sum[$getGlobalUserVar[banco;$authorID];$get[mds]];$authorID]

$onlyIf[$get[mds]!=;**[ 💸 \]** Digite a quantidade de dinheiro que você quer depositar.]
$onlyIf[$isNumber[$get[mds]]==true;**[ 🔢 \]** Digite apenas números na quantia.]
$onlyIf[$checkContains[$toLowercase[$get[mds]];.;,]==false;**[ 🚫 \]** Sem Numeros Decimais!]
$onlyIf[$get[mds]>=1;**[ 💰 \]** Você só pode depositar mais de **1 AyCoin**.]
$onlyIf[$get[mds]<=$getGlobalUserVar[coins;$authorID];**[ 💸 \]** Você não tem essa quantia de dinheiro na carteira.]
$onlyIf[$checkContains[$uri[$message;encode];%0A]==false;[ \❌ ] Não faça quebra de Linhas por favor!]
$let[mds;$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$noMentionMessage;kk;000000;1];k;000;1];m;000000;1];b;000000000;1];all;$getGlobalUserVar[coins;$authorID];1];t;000000000000;1]]
`
}