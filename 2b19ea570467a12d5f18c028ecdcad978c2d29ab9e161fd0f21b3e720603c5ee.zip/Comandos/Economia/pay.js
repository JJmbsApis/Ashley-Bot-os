module.exports = {
 name: "pay",
 aliases: ['pagar', 'transferir', 'pix'],
 code: `
**[ 💸 \]** <@$authorID> transferiu \`$numberSeparator[$get[mds]]\` AyCoins para <@$mentioned[1]> (<t:$truncate[$divide[$dateStamp;1000]]:R>).

$setGlobalUserVar[coins;$sum[$getGlobalUserVar[coins;$mentioned[1]];$get[mds]];$mentioned[1]]

$setGlobalUserVar[coins;$sub[$getGlobalUserVar[coins;$authorID];$get[mds]];$authorID]

$onlyIf[$get[mds]!=;**[ 💸 \]** Digite a quantidade de dinheiro que você quer pagar.]
$onlyIf[$mentionedUsersCount==1;**[ 👤 \]** Mencione um usuário para pagar.]
$onlyIf[$isNumber[$get[mds]]==true;**[ 🔢 \]** Digite apenas números na quantia.]
$onlyIf[$checkContains[$toLowercase[$get[mds]];.;,]==false;**[ 🚫 \]** Sem Numeros Decimais!]
$onlyIf[$get[mds]>=1;**[ 💰 \]** Você só pode pagar mais de **1 AyCoin**.]
$onlyIf[$mentioned[1]!=$authorID;**[ ❌ \]** Você não pode pagar para si mesmo.]
$onlyIf[$get[mds]<=$getGlobalUserVar[coins;$authorID];**[ 💸 \]** Você não tem essa quantia de dinheiro na carteira.]
$onlyIf[$checkContains[$uri[$message;encode];%0A]==false;[ \❌ ] Não faça quebra de Linhas por favor!]
$let[mds;$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$noMentionMessage;kk;000000;1];k;000;1];m;000000;1];b;000000000;1];all;$getGlobalUserVar[coins;$authorID];1];t;000000000000;1]]
`
}