module.exports = {
  name: "aycoins",
  aliases: ['coins', 'moedas', 'saldo', 'bal', 'balance', 'wallet', 'carteira', 'cash', 'money', 'banco', 'atm'],
  $if: "v4",
  code: `
  $if[$checkCondition[$findUser[$message;yes]==$authorID]==false]
  > $username[$findUser[$message;yes]] Tem \`$numberSeparator[$getGlobalUserVar[coins;$findUser[$message;yes]]]\` Aycoins na Carteira

  > $username[$findUser[$message;yes]] Tem \`$numberSeparator[$getGlobalUserVar[banco;$findUser[$message;yes]]]\` Aycoins no Banco

  $else

  > Você Tem \`$numberSeparator[$getGlobalUserVar[coins;$findUser[$message;yes]]]\` Aycoins na Carteira

  > Você Tem \`$numberSeparator[$getGlobalUserVar[banco;$findUser[$message;yes]]]\` Aycoins no Banco

  $endif
`
}