module.exports = ({
  name: "daily",
  aliases: ['diário', 'diario'],
  $if: "v4",
  code: `
Você Ganhou \`$numberSeparator[$get[daily];,]\` Aycoins no seu Daily! ( <t:$truncate[$divide[$dateStamp;1000]]:R> )
$setGlobalUserVar[coins;$sum[$getGlobalUserVar[coins;$authorID];$get[daily]];$authorID]

$let[daily;$random[1000;6000]]
$globalCooldown[1d;Espere 1 dia para coletar seu Diário novamente!]
`
})