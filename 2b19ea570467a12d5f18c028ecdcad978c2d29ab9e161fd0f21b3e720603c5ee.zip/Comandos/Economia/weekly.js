module.exports = ({
  name: "weekly",
  aliases: ['semanal', 'wk'],
  $if: "v4",
  code: `

Você Ganhou \`$numberSeparator[$get[daily];,]\` Aycoins no seu Weekly! ( <t:$truncate[$divide[$dateStamp;1000]]:R> )
$setGlobalUserVar[coins;$sum[$getGlobalUserVar[coins];$get[daily]];$authorID]

$let[daily;$random[7000;42000]]
$globalCooldown[7d;Espere 7 dias para coletar seu Semanal novamente!]
`
})