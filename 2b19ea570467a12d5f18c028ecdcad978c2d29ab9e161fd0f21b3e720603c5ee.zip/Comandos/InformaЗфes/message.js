module.exports = {
 name: "messages",
 aliases: ['messagecount', 'mensagens', 'msgs', 'msg'],
 $if: "v4",
 code: `
 $if[$message[1]==help]
 $title[1;Sistema de Contar Mensagens]
 $description[1;Você quando manda uma mensagem automaticante ela é somada ao seu contador, mas isso funciona apenas se eu estiver no servidor!]
 $endif
 $if[$message[1]==ajuda]
 $title[1;Sistema de Contar Mensagens]
 $description[1;Você quando manda uma mensagem automaticante ela é somada ao seu contador, mas isso funciona apenas se eu estiver no servidor!]
 $endif
 $if[$message[1]==]
 $title[1;Sistema de Contar Mensagens]
 $description[1;Você possuí \`$getUserVar[messages;$authorID]\` Mensagens!]
 $endif
 `
}