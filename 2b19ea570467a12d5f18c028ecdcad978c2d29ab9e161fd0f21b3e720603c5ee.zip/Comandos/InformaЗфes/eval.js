module.exports = {
 name: "eval",
 aliases: ['ev', 'e', 'run', 'execute', 'executar', 'cmdexecute'],
 $if: "v4",
 code: `
 $eval[$message]
   $onlyForIDs[942195785418801222;885897586945458216;]
   `}