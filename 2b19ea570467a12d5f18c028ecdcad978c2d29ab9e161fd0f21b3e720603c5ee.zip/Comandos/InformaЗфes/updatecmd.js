module.exports = {
 name: "update",
 aliases: ['upd-db', 'upd'],
 code: `
:white_check_mark: Todos Comandos foram Atualizados!
$log[$user[$authorID;tag] Atualizou os comandos!]
$updateCommands
   $onlyForIDs[942195785418801222;885897586945458216;]
   `}