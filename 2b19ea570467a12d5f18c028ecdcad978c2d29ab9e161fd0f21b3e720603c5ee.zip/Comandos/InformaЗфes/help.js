
module.exports = [{
name: "help",
aliases: ['ajuda', 'ayuda', 'h'],
code: `$title[1;( :question: ) Painel de Ajuda.]
$description[1;Olá, precisa de ajuda?
Irei listar uma Lista de meus Comandos a baixo, mas antes veja
algumas informações minhas:

> <a:SetaRoxa:974290916317757500> \`$allMembersCount\` **Membros.**
> <a:SetaRoxa:974290916317757500> \`$serverCount\` **Servidores.**
$addSelectMenu[1;selectmenu;Selecione a Categoria;1;1;false;Economia:Comandos de Economia:valor1:;Informações:Comandos de Informações:valor2:;Configurações:Comandos de Configurações:valor3:;Diversão:Comandos de Diversão:valor4:;Utilitários:Comandos Utilitários:valor5:]`
}, {
//Interacción (Selección 1)
name: "selectmenu",
type: "interaction",
prototype: "selectMenu",
code: `
$interactionUpdate[<@$interactionData[author.id]>;{newEmbed:{description:
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]daily\`
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]weekly\`
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]pay\`
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]saldo\`(**atm, aycoins, coins, bal.**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]depositar\` (**dep, deposito.**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]sacar\` (**sac, saque.**)}:{title:Painel de Ajuda - Economia}};;;;]
$onlyIf[$interactionData[values[0]]==valor1;]`
}, {
//Interacción (Selección 2)
name: "selectmenu",
type: "interaction",
prototype: "selectMenu",
code: `
$interactionUpdate[<@$interactionData[author.id]>;{newEmbed:{description:
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]botinfo\` (**bi**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]help\` (**h**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]ping\` (**p**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]userinfo (@user)\` (**ui**)}:{title:Painel de Ajuda - Informações}};;;;]
$onlyIf[$interactionData[values[0]]==valor2;]`
}, {

name: "selectmenu",
type: "interaction",
prototype: "selectMenu",
code: `
$interactionUpdate[<@$interactionData[author.id]>;{newEmbed:{description:
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]prefix (prefix|reset)\` (**sp, prefixo, setprefix**)}:{title:Painel de Ajuda - Configuração}};;;;]
$onlyIf[$interactionData[values[0]]==valor3;]`
}, {

name: "selectmenu",
type: "interaction",
prototype: "selectMenu",
code: `
$interactionUpdate[<@$interactionData[author.id]>;{newEmbed:{description:
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]laranjo <frase>\` (**orange**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]snake\` (**snk**)
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]ship <@user> <@user>\` (**shipar**)}:{title:Painel de Ajuda - Diversão}};;;;]
$onlyIf[$interactionData[values[0]]==valor4;]`
}, {

name: "selectmenu",
type: "interaction",
prototype: "selectMenu",
code: `
$interactionUpdate[<@$interactionData[author.id]>;{newEmbed:{description:
> <a:SetaRoxa:974290916317757500> \`$getServerVar[Prefix]calcular <expressão>\` (**calc, calculate.**)}:{title:Painel de Ajuda - Diversão}};;;;]
$onlyIf[$interactionData[values[0]]==valor5;]`
}]

