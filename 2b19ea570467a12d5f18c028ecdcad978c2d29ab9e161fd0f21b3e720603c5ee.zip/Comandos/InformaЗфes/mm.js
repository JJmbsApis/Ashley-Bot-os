module.exports = {
    name: "<@$clientID>",
    aliases: ['<@!$clientID>'],
    nonPrefixed: true,
    code: `Opa <@$authorID> Meu Prefixo aqui é \`$getServerVar[Prefix]\`, você pode tentar usar \`$getServerVar[Prefix]help\`.
$onlyIf[$noMentionMessage==;]
  `
  }