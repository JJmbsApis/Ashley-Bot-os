module.exports = {
  name: "ping",
  aliases: ['p'],
  code: `
_Pong!_ \🏓
> Websocket Ping: \`$pingms\`
> Database Ping: \`$dbPingms\`
`
} 