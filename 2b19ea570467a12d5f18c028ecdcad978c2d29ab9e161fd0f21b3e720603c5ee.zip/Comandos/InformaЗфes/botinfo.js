module.exports = {
  name: "botinfo",
  aliases: ['bi', 'ib', 'infobot'],
  code: `
    $title[1;( <a:info:972993253286752306> ) Minhas Informações.]
 $description[1;__Olá eu sou a Ashley Bot e estou aqui para divertir você!
Aqui Vai algumas informações sobre mim:__
> ( <a:nodejs:972995371938746419> ) **Fui desenvolvida na Linguagem \`Javascript\` usando a Livraria \`Aoi.js\`**
> ( <a:DevDeveloper:972995695592222720> ) **Fui criada por \`$user[942195785418801222;tag]\`**
> ( <:server:973726487758909470> ) **Tenho \`$allMembersCount\` Amigos, e estou em \`$serverCount\` Servidores!**
> ( <:engrenagi:973726729602498611> ) **Tenho \`$commandsCount\` Comandos!**
> ( <:clipse:973727018837487676> ) **[Clique Aqui](https://discord.com/api/oauth2/authorize?client_id=972693141159301173&permissions=8&scope=bot%20applications.commands) para me Convidar ao seu servidor!**
> ( <:data:973727254859366410> ) **Fui criada em <t:$truncate[$divide[$creationDate[$clientID;ms];1000]]:F> (<t:$truncate[$divide[$creationDate[$clientID;ms];1000]]:R>)**
> ( <a:api_latency:973727891013648425> )  **Meu ping está em \`$pingms\` e Já usei \`$truncate[$ram]MB\` de Memória ram!**
> ( <:relogio:976471690068525107> ) **Estou Acordada desde <t:$getVar[uptime]:F> (<t:$getVar[uptime]:R>)**
]
  `
}