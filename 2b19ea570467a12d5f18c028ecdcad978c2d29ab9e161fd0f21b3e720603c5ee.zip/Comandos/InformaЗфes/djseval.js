module.exports = {
    name: "deval",
    aliases: ['dev', 'de', 'drun', 'dexecute', 'dexecutar', 'dcmdexecute'],
    $if: "v4",
    code: `
    $djsEval[true;$message]
      $onlyForIDs[942195785418801222;885897586945458216;]
      `}