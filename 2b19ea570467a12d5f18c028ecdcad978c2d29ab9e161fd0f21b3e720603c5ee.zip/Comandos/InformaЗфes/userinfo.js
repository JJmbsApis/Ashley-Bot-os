module.exports = [{
  name: "userinfo",
  aliases: ['ui', 'iu', 'infouser'],
  $if: "v4",
  $userRoles: "v4",
  code: `
$title[1;:crown: $username[$findUser[$message;yes]]]
$description[1;
> <a:SetaRoxa:974290916317757500> ( :label: ) **Nome e Tag**
> \`$username[$findUser[$message;yes]]#$discriminator[$findUser[$message;yes]]\`
> <a:SetaRoxa:974290916317757500> ( <:clipse:973727018837487676> ) **ID**
> \`$findUser[$message;yes]\`
> <a:SetaRoxa:974290916317757500> ( :lock_with_ink_pen: ) **Status DM**
> \`$replaceText[$replaceText[$isUserDMEnabled[$findUser[$message;yes]];false;Fechada;1];true;Aberta;1]\`
> <a:SetaRoxa:974290916317757500> ( <:data:973727254859366410> ) **Criação da Conta**
> <t:$truncate[$divide[$creationDate[$findUser[$message;yes];ms];1000]]:F> (<t:$truncate[$divide[$creationDate[$findUser[$message;yes];ms];1000]]:R>)
> <a:SetaRoxa:974290916317757500> ( <:data:973727254859366410> ) **Entrou aqui em**
> <t:$truncate[$divide[$memberJoinedDate[$findUser[$message;yes];$guildID];1000]]:F>(<t:$truncate[$divide[$memberJoinedDate[$findUser[$message;yes];$guildID];1000]]:R>) 
> <a:SetaRoxa:974290916317757500> ( <:robo:976758157902745620> ) **É um Bot?**
> \`$replaceText[$replaceText[$isBot[$findUser[$message;yes]];true;Sim;1];false;Não;1]\`
> <a:SetaRoxa:974290916317757500> ( <:roleicon:976768004350181428> ) **Cargos**
> \`$replaceText[$replaceText[$userRoles[$findUser[$message;yes]];, @everyone;.;1];@everyone;Nenhum;1]\`
> <a:SetaRoxa:974290916317757500> ( \⬆️ ) **Maior Cargo**
> \`$replaceText[$roleName[$highestRole[$findUser[$message;yes]]];@everyone;Nenhum;1] .\`
> <a:SetaRoxa:974290916317757500> ( 😃 ) **Badges**
> $replaceText[$replaceText[$replaceText[$replaceText[$getUserBadges[$findUser[$message;yes]];HOUSE_BRAVERY;<:HOUSE_BRAVERY:976759412444254238>;1];HOUSE_BALANCE;<:HOUSE_BALANCE:976759500704997376>;1];HOUSE_BRILLIANCE;<:HOUSE_BRILLIANCE:976759585111146516>;1];none;\`Nenhuma\`;1]]
$thumbnail[1;$userAvatar[$findUser[$message;yes]]]
$title[2;<:moderator:976768218775572491> Permissões]
$description[2;
> <a:SetaRoxa:974290916317757500> ( <:moderator:976768218775572491> ) **Permissões**
> \`$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$replaceText[$toUppercase[$userPerms[$findUser[$message;yes];, ]];CREATEINVITE;Criar Convites;1];KICK;Expulsar Membros;1];BAN;Banir Membros;1];ADMIN;Administrador;1];MANAGECHANNEL;Gerenciar Canais;1];MANAGESERVER;Gerenciar Servidor;1];ADDREACTIONS;Adicionar Reações;1];VIEWAUDITLOG;Ver Registro de Auditoria;1];, PRIORITYSPEAKER;;1];STREAM;Transmitir Tela;1];VIEWCHANNEL;Ver Canais;1];SENDMESSAGE;Mandar Mensagens;1];SENDTTS;Mandar Mensagens em TTS;1];MANAGEMESSAGES;Gerenciar Mensagens;1];EMBEDLINKS;Links Incorporados;1];ATTACHFILES;Enviar Arquivos;1];READMESSAGEHISTORY;Ver Histórico de Mensagens;1];MENTIONEVERYONE;Mencionar Everyone e Todos os Cargos;1];EXTERNALEMOJIS;Usar Emojis Externos;1];, VIEWGUILDINSIGHTS;;1];CONNECT;Conectar;1];SPEAK;Falar;1];MUTEMEMBERS;Silenciar Membros;1];DEAFENMEMBERS;Ensurdecer Membros;1];MOVEMEMBERS;Mover Membros;1];USEVAD;Usar VAD;1];CHANGENICKNAME;Mudar Apelido;1];MANAGENICKNAMES;Gerenciar Apelidos;1];MANAGEROLES;Gerenciar Cargos;1];MANAGEWEBHOOKS;Gerenciar WebHooks;1];MANAGEEMOJISANDSTICKERS;Gerenciar Emojis & Figurinhas;1];USEAPPCMDS;Usar Comandos Slash;1];REQUESTTOSPEAK;Pedir Para Falar;1];MANAGEEVENTS;Gerenciar Eventos;1];MANAGETHREADS;Gerenciar Tópicos;1];USEPUBLICTHREADS;Usar Tópicos Públicos;1];CREATEPUBLICTHREADS;Criar Tópicos Públicos;1];USEPRIVATETHREADS;Usar Tópicos Privados;1];CREATEPRIVATETHREADS;Criar Tópicos Privados;1];EXTERNALSTICKERS;Usar Figurinhas Externas;1];SENDMESSAGEINTHREADS;Mandar Mensagens em Tópicos;1];, STARTEMBEDDEDACTIVITIES;;1];, MODERATEMEMBERS;;1].\`]
$onlyIf[$memberExists[$findUser[$message;yes]]!=false;:x: | Esse usuário precisa estar no servidor.]
`
}]